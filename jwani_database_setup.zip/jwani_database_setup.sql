-- =====================================================================
--  سیستەمی ژمێریاری ژوانی گەشتیاری — Database Setup
--  Jwani Accounting System — full schema + initial data
--
--  HOW TO USE (cPanel):
--   1. Open cPanel  ->  phpMyAdmin
--   2. On the left, click your database (e.g. zhwadqwq_db)
--   3. Click the "Import" tab at the top
--   4. Choose this file (jwani_database_setup.sql) and click "Go"
--   5. Done. Log in with: admin@jwani.com / password
--
--  Charset: utf8mb4 (full Kurdish/Arabic support)
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET time_zone = '+00:00';

-- ---------------------------------------------------------------------
-- migrations (so Laravel knows the schema is already applied)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- users
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- password_reset_tokens
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- sessions
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `payload` longtext NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- exchange_rates
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `exchange_rates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `usd_to_iqd` decimal(12,4) NOT NULL COMMENT '1 USD = X IQD',
  `notes` varchar(255) DEFAULT NULL,
  `set_by` varchar(255) DEFAULT NULL,
  `effective_from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_rates_effective_from_index` (`effective_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- clients
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text,
  `notes` text,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_name_index` (`name`),
  KEY `clients_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- transactions
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `type` enum('sale','purchase','debit','credit') NOT NULL COMMENT 'sale=فرۆشتن, purchase=کڕین, debit=قەرز/بردراو, credit=دانەوەی قەرز/هێنراو',
  `currency` enum('USD','IQD') NOT NULL DEFAULT 'USD',
  `amount` decimal(15,2) NOT NULL COMMENT 'Original entered amount',
  `amount_usd` decimal(15,4) NOT NULL,
  `amount_iqd` decimal(15,2) NOT NULL,
  `exchange_rate_usd_to_iqd` decimal(12,4) NOT NULL COMMENT 'Rate locked at transaction creation. Historical accuracy preserved.',
  `description` varchar(255) NOT NULL,
  `reference_number` varchar(50) NOT NULL,
  `transaction_date` date NOT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transactions_reference_number_unique` (`reference_number`),
  KEY `transactions_client_id_transaction_date_index` (`client_id`,`transaction_date`),
  KEY `transactions_type_transaction_date_index` (`type`,`transaction_date`),
  KEY `transactions_transaction_date_index` (`transaction_date`),
  KEY `transactions_reference_number_index` (`reference_number`),
  KEY `transactions_user_id_foreign` (`user_id`),
  CONSTRAINT `transactions_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  INITIAL DATA
-- =====================================================================

-- Mark migrations as applied
INSERT INTO `migrations` (`migration`, `batch`) VALUES
  ('2024_01_01_000001_create_users_table', 1),
  ('2024_01_01_000002_create_exchange_rates_table', 1),
  ('2024_01_01_000003_create_clients_table', 1),
  ('2024_01_01_000004_create_transactions_table', 1);

-- Admin user  (login: admin@jwani.com  /  password)
INSERT INTO `users` (`name`, `email`, `password`, `created_at`, `updated_at`) VALUES
  ('بەڕێوەبەر', 'admin@jwani.com', '$2y$10$oMqwFOWnc4ebLn8p5hBLkOFNHeOyBszF4kwmjEoqbpqEAUcKNupXK', NOW(), NOW());

-- Initial exchange rate
INSERT INTO `exchange_rates` (`usd_to_iqd`, `notes`, `set_by`, `effective_from`, `created_at`, `updated_at`) VALUES
  (1310.0000, 'ڕێژەی سەرەتایی', 'بەڕێوەبەر', NOW(), NOW(), NOW());

-- Sample clients
INSERT INTO `clients` (`name`, `phone`, `address`, `is_active`, `created_at`, `updated_at`) VALUES
  ('ئەحمەد حسێن', '07501234567', 'هەولێر', 1, NOW(), NOW()),
  ('سارا محمد', '07709876543', 'سلێمانی', 1, NOW(), NOW()),
  ('کارزان عبدوللا', '07701112233', 'دهۆک', 1, NOW(), NOW()),
  ('شرکەتی نمونە', '07701234567', 'هەولێر، گەڕەکی کەرکووک', 1, NOW(), NOW());

SET FOREIGN_KEY_CHECKS = 1;
-- =====================================================================
--  END — Log in at your site with  admin@jwani.com  /  password
--  IMPORTANT: change this password immediately after first login.
-- =====================================================================
